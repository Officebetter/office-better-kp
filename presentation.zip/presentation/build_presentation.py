# Презентація Office Better «Новорічні подарунки» — пергаментний стиль, 16:9
# Презентація Office Better «Новорічні подарунки» для розсилки клієнтам (пергаментний стиль, 16:9).
# Запуск:  python3 build_presentation.py "Соул"      — версія для одного менеджера (пошук за частиною імені)
#          python3 build_presentation.py all         — версії для всіх менеджерів
# Результат: папка out/ поруч зі скриптом. Потрібні: playwright (chromium), pikepdf, Pillow.
import base64, os, sys, subprocess
HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)

MANAGERS = [
    ("Максим Мошков", "+38 (093) 884-63-30", "mm@office-better.com", "Maksym_Moshkov"),
    ("Юлія Львович", "+38 (063) 165-58-29", "lvovych.yuliia@office-better.com", "Yuliia_Lvovych"),
    ("Ірина Бондаревська", "+38 (063) 788-48-02", "iryna.bondarevska@office-better.com", "Iryna_Bondarevska"),
    ("Дар’я Труш", "+38 (063) 663-11-94", "daria.trush@office-better.com", "Daria_Trush"),
    ("Катерина Труш", "+38 (063) 220-63-38", "kateryna.trush@office-better.com", "Kateryna_Trush"),
    ("Світлана Соул", "+38 (063) 165-58-22", "svitlana.soul@office-better.com", "Svitlana_Soul"),
    ("Ольга Грабовська", "+38 (063) 220-65-53", "olha.hrabovska@office-better.com", "Olha_Hrabovska"),
    ("Анастасія Якубовська", "+38 (063) 220-63-72", "yakubovska.anastasiia@office-better.com", "Anastasiia_Yakubovska"),
    ("Юлія Козаченко", "+38 (063) 165-58-35", "kozachenko.yulia@office-better.com", "Yuliia_Kozachenko"),
    ("Тетяна Арнаутова", "+38 (063) 195-22-42", "tetiana.arnautova@office-better.com", "Tetiana_Arnautova"),
    ("Анна Борищак", "+38 (063) 378-90-23", "anna.boryshchak@office-better.com", "Anna_Boryshchak"),
]
arg = sys.argv[1] if len(sys.argv) > 1 else ''
if arg.lower() == 'all':
    for mg in MANAGERS: subprocess.run([sys.executable, __file__, mg[0]], check=True)
    sys.exit()
found = [mg for mg in MANAGERS if arg and arg.lower().replace("'", "’") in mg[0].lower()]
if len(found) != 1:
    sys.exit('Вкажіть одного менеджера (частину імені) або all. Знайдено: ' + ', '.join(m[0] for m in found))
NAME, PHONE, EMAIL, SLUG = found[0]
MANAGER = dict(name=NAME, phone=PHONE, email=EMAIL)
os.makedirs('out', exist_ok=True)
def b64(p): return base64.b64encode(open(p, 'rb').read()).decode()
def img(k, cls='', style=''):
    ext = 'jpeg' if k.endswith('.jpg') else 'webp'
    path = f'img/{k}' if '.' in k else f'img/{k}.webp'
    return f'<img class="{cls}" style="{style}" src="data:image/{ext};base64,{b64(path)}" alt="">'

fonts = ''
for w, n in ((500, 'Medium'), (600, 'SemiBold'), (700, 'Bold'), (800, 'ExtraBold'), (900, 'Black')):
    fonts += f"@font-face{{font-family:'Montserrat';font-weight:{w};src:url(data:font/ttf;base64,{b64(f'fonts/Montserrat-{n}.ttf')}) format('truetype');}}\n"
fonts += f"@font-face{{font-family:'Caveat';font-weight:700;src:url(data:font/ttf;base64,{b64('fonts/Caveat-Bold.ttf')}) format('truetype');}}\n"

LOGO = img('logo2', 'logo')
# рукописна стрілка
ARROW = '''<svg class="arrow" viewBox="0 0 120 70"><path d="M6 10 C 40 2, 78 14, 96 50" fill="none" stroke="#b82266" stroke-width="3" stroke-linecap="round"/>
<path d="M84 44 L97 53 L101 37" fill="none" stroke="#b82266" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>'''

slides = []
slides.append(f'''<section class="slide cover">
  {LOGO}
  <div class="cv-l">
    <div class="hand kick">Новий рік 2027</div>
    <h1>Новорічні подарунки, які хочеться розкривати</h1>
    <p class="lead">Хамон і витримані сири, ковбаси, паштети, ігристе, кава, чай, горіхи й солодощі — усе, щоб зібрати смачні новорічні кошики, і навіть те, чого немає в каталозі.</p>
    <p class="lead">Наша команда допоможе підібрати найкращий варіант, не роздуваючи бюджет, і доставить усе в найкращому вигляді.</p>
    <p class="lead">Ми працюємо з компаніями, тож усе буде чітко й прозоро — і ваша бухгалтерія теж буде задоволена.</p>
  </div>
  <div class="cv-r">
    {img('board', 'board')}
  </div>
  {img('m_bag', 'm-cover')}
  <div class="site">office-better.com</div>
</section>''')


CHK = '<svg viewBox="0 0 20 20" class="chk"><rect x="1" y="3" width="15" height="15" rx="4" fill="none" stroke="#2f2987" stroke-width="2"/><path d="M5 10.5 L9 15 L18.5 2.5" fill="none" stroke="#6259ff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
def elf_tag(side=''):
    m = MANAGER
    return f'<div class="elf {side}"><span class="hand">ваш персональний ельф</span><b>{m["name"]}</b><small>{m["phone"]} · {m["email"]}</small></div>'

# 2 — як ми допомагаємо
steps = [('Розкажіть про свою команду', 'Скільки людей вітаєте, на яку суму розраховуєте, що люблять у колективі: хтось без м’яса, хтось без алкоголю, а хтось обожнює солодке.'),
         ('Отримайте кілька ідей', 'Ваш ельф прорахує і складе кілька варіантів наповнення — від улюбленої класики до гастрономічних відкриттів.'),
         ('Обирайте й готуйтеся до свята', 'Погоджуєте склад, і ми привозимо все до вас. Залишається скласти подарунки й побачити усмішки колег.')]
st = ''.join(f'<div class="step"><div class="num hand">{i}</div><div><b>{t}</b><p>{d}</p></div></div>' for i, (t, d) in enumerate(steps, 1))
slides.append(f"""<section class="slide">
  {LOGO}
  <div class="title"><h2>Як ми допомагаємо</h2><div class="hand sub">ви плануєте свято — ми беремо на себе пошук</div></div>
  <div class="steps">{st}</div>
  <div class="hand sale">один постачальник — і жодних пошуків по десятках сайтів</div>
  {img('m_check', 'm-check')}
  {elf_tag()}
</section>""")

# 3 — вітрина
items = [('a02', 'хамон і прошуто', -4), ('a03', 'ковбаси', 3), ('a04', 'сири', -2), ('a05', 'ігристе й вино', 4),
         ('a06', 'горіхи й сухофрукти', 3), ('a07', 'святкова випічка', -3), ('a08', 'кава й чай', 2), ('a10', 'шоколад і цукерки', -4), ('a15', 'паштети й джеми', 3), ('a09', 'подарункові пакети', -2)]
cells = ''.join(f'<figure style="--r:{r}deg">{img(k)}<figcaption class="hand">{n}</figcaption></figure>' for k, n, r in items)
slides.append(f"""<section class="slide">
  {LOGO}
  <div class="title"><h2>Що покласти в кошик</h2><div class="hand sub">смаки, які збирають за одним столом</div></div>
  <div class="grid">{cells}</div>
  {img('m_tray', 'm-tray')}
  {elf_tag()}
</section>""")

# 4 — цукеркові подарунки
slides.append(f"""<section class="slide">
  {LOGO}
  <div class="title"><h2>Солодкі подарунки для малечі</h2><div class="hand sub">смак дитинства, коли чекаєш на диво</div></div>
  <div class="kids-txt">
    <p class="lead">Пам’ятаєте, як у дитинстві розгортали новорічний подарунок і шукали найсмачнішу цукерку? Подаруйте це відчуття дітям ваших співробітників і партнерів.</p>
    <p class="lead">Підберемо цукеркові набори від українських виробників: яскраві коробочки-будиночки, тубуси, дерев’яні скриньки. А оскільки всі дорослі в душі трохи діти, такі подарунки чудово порадують і колег.</p>
  </div>
  {img('a14', 'kids-art')}
  {img('m_candy', 'm-candy')}
  {elf_tag('left')}
</section>""")

# 5 — з нами зручно
perks = [('Ціни з ПДВ', 'Одразу бачите фінальну суму, без сюрпризів для бухгалтерії.'),
         ('З договором і без', 'Як вам зручно — так і оформимо.'),
         ('Електронний документообіг', 'Підписуємо документи онлайн, без паперової тяганини.'),
         ('Доставка', 'Привеземо в офіс чи на іншу адресу, яку назвете.'),
         ('Знижки від обсягу', 'Що більше подарунків, то вигідніша ціна.'),
         ('Знайдемо під запит', 'Немає потрібного в каталозі? Пошукаємо в наших постачальників.'),
         ('Один постачальник на все свято', 'Кошики, дитячі подарунки, пакети, а після свят — кава й усе для офісу.')]
pk = ''.join(f'<li>{CHK}<div><b>{t}</b><span>{d}</span></div></li>' for t, d in perks)
slides.append(f"""<section class="slide">
  {LOGO}
  <div class="title"><h2>Чому з нами легко</h2><div class="hand sub">працюємо так, як зручно вам</div></div>
  <ul class="perks">{pk}</ul>
  {img('m_bags3', 'm-bags')}
  {elf_tag('left')}
</section>""")

# 6 — фінал
m = MANAGER
slides.append(f"""<section class="slide final">
  {LOGO}
  <div class="fin">
    <h2>Зберімо подарунки, які запам’ятаються</h2>
    <p class="lead">Напишіть або зателефонуйте своєму ельфу — розпитаємо про вашу команду і запропонуємо кілька варіантів наповнення. Що раніше почнемо, то більше буде з чого обрати.</p>
    <div class="card"><span class="hand">ваш персональний ельф</span><b>{m["name"]}</b><span class="ph">{m["phone"]}</span><span class="ph">{m["email"]}</span></div>
  </div>
  {img('m_wave', 'm-wave')}
  <div class="site" style="right:auto;left:16mm">office-better.com</div>
</section>""")

css = '''
@page { size: 338.67mm 190.5mm; margin: 0; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Montserrat', Arial, sans-serif; color: #07002C; -webkit-print-color-adjust: exact; print-color-adjust: exact; background: #777; }
.slide { width: 338.67mm; height: 190.5mm; position: relative; overflow: hidden; margin: 0 auto 6mm; break-after: page;
  background: url(data:image/jpeg;base64,PARCH) center / cover; }
.slide:last-child { break-after: auto; }
@media print { body { background: none; } .slide { margin: 0; } }
img { mix-blend-mode: multiply; }
.hand { font-family: 'Caveat', cursive; font-weight: 700; color: #b82266; }
.logo { position: absolute; left: 16mm; top: 13mm; width: 42mm; }
.site { position: absolute; right: 16mm; bottom: 8mm; font-size: 8pt; font-weight: 700; color: #2f2987; letter-spacing: .4pt; opacity: .8; }

.cv-l { position: absolute; left: 16mm; top: 40mm; width: 128mm; }
.kick { font-size: 24pt; margin-bottom: 1mm; transform: rotate(-2deg); transform-origin: left; }
.cover h1 { font-size: 30pt; line-height: 1.04; font-weight: 900; color: #2f2987; letter-spacing: -.5pt; }
.lead { font-size: 10.5pt; line-height: 1.5; color: #3b2f4a; margin-top: 3.5mm; max-width: 116mm; font-weight: 500; }
.cv-r { position: absolute; right: 8mm; top: 10mm; width: 182mm; height: 160mm; }
.board { position: absolute; right: 4mm; top: 8mm; width: 168mm; transform: rotate(-3deg); }
.note { position: absolute; right: 6mm; bottom: -2mm; font-size: 21pt; transform: rotate(-3deg); }
.arrow { position: absolute; right: 50mm; bottom: 10mm; width: 24mm; transform: rotate(200deg); }
.m-cover { position: absolute; left: 16mm; bottom: -3mm; width: 46mm; }

.title { position: absolute; left: 70mm; right: 16mm; top: 14mm; text-align: right; }
h2 { font-size: 26pt; font-weight: 900; color: #2f2987; letter-spacing: -.4pt; }
.sub { font-size: 18pt; margin-top: -1mm; }
.grid { position: absolute; left: 58mm; right: 14mm; top: 40mm; bottom: 12mm; display: grid; grid-template-columns: repeat(4, 1fr); grid-template-rows: 1fr 1fr; gap: 2mm 6mm; }
figure { display: flex; flex-direction: column; align-items: center; justify-content: flex-end; transform: rotate(var(--r)); min-height: 0; }
figure img { max-width: 100%; max-height: 52mm; object-fit: contain; flex: 1; min-height: 0; }
figcaption { font-size: 19pt; line-height: 1; margin-top: 1mm; color: #2f2987; }
.m-tray { position: absolute; left: 6mm; bottom: -4mm; width: 56mm; }

.chk { width: 7.5mm; height: 7.5mm; flex: none; margin-top: .6mm; }
.elf { position: absolute; right: 16mm; bottom: 8mm; text-align: right; font-size: 8pt; color: #3b2f4a; }
.elf .hand { display: block; font-size: 15pt; line-height: 1; }
.elf b { display: block; font-size: 11pt; font-weight: 800; color: #07002C; }
.elf small { font-size: 8pt; }
.elf.left { right: auto; left: 16mm; text-align: left; }
.steps { position: absolute; left: 92mm; right: 18mm; top: 50mm; display: grid; gap: 7mm; }
.step { display: grid; grid-template-columns: 16mm 1fr; gap: 5mm; align-items: start; }
.num { font-size: 46pt; line-height: .8; color: #b82266; text-align: center; }
.step b { display: block; font-size: 17pt; font-weight: 800; color: #2f2987; margin-bottom: 1.2mm; }
.step p { font-size: 11.5pt; line-height: 1.5; color: #3b2f4a; font-weight: 500; max-width: 170mm; }
.sale { position: absolute; left: 100mm; bottom: 26mm; font-size: 23pt; transform: rotate(-2deg); }
.m-check { position: absolute; left: 12mm; bottom: -4mm; width: 74mm; }
.grid { left: 62mm !important; right: 12mm !important; bottom: 26mm !important; top: 38mm !important; grid-template-columns: repeat(5, 1fr) !important; }
.bag { position: absolute; right: 14mm; top: 46mm; width: 56mm; text-align: center; }
.bag img { width: 46mm; transform: rotate(3deg); }
.bag .hand { font-size: 17pt; line-height: 1.05; margin-top: 1mm; transform: rotate(-2deg); }
.kids-txt { position: absolute; left: 16mm; top: 48mm; width: 126mm; display: grid; gap: 4mm; }
.big { font-size: 22pt; transform: rotate(-2deg); margin-top: 3mm; }
.kids-art { position: absolute; right: 22mm; top: 44mm; width: 168mm; transform: rotate(-2deg); }
.m-candy { position: absolute; right: 14mm; bottom: -4mm; width: 50mm; }
.perks { list-style: none; position: absolute; left: 16mm; top: 46mm; width: 222mm; display: grid; grid-template-columns: 1fr 1fr; gap: 7mm 12mm; }
.perks li { display: flex; gap: 3.5mm; align-items: flex-start; }
.perks b { display: block; font-size: 14.5pt; font-weight: 800; color: #2f2987; }
.perks span { font-size: 10.5pt; line-height: 1.4; display: block; color: #3b2f4a; font-weight: 500; }
.m-bags { position: absolute; right: 18mm; bottom: 16mm; width: 86mm; }
.fin { position: absolute; left: 16mm; top: 46mm; width: 170mm; }
.final h2 { font-size: 32pt; line-height: 1.06; }
.final .lead { max-width: 150mm; }
.card { margin-top: 8mm; display: inline-flex; min-width: 112mm; flex-direction: column; padding: 5mm 8mm 6mm; border: .6mm solid #2f2987; border-radius: 5mm; transform: rotate(-1.5deg); }
.card .hand { font-size: 18pt; line-height: 1; }
.card b { font-size: 17pt; font-weight: 900; color: #07002C; margin: 1mm 0 1.5mm; }
.card .ph { font-size: 11pt; font-weight: 600; color: #2f2987; }
.m-wave { position: absolute; right: 14mm; bottom: -6mm; width: 118mm; }
'''.replace('PARCH', b64('img/parchment.jpg'))

html = f'<!doctype html><html lang="uk"><head><meta charset="utf-8"><title>Новорічні подарунки Office Better</title><style>{fonts}{css}</style></head><body>{"".join(slides)}</body></html>'
open('out/_tmp.html', 'w').write(html)
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); pg = b.new_page()
    pg.goto('file://' + os.path.join(HERE, 'out/_tmp.html')); pg.wait_for_timeout(800)
    pg.pdf(path='out/_tmp.pdf', width='338.67mm', height='190.5mm', print_background=True, margin={'top': '0', 'right': '0', 'bottom': '0', 'left': '0'})
    b.close()


# стиснення картинок і унікальні назви шрифтів
import pikepdf, io
from PIL import Image
src, dst = 'out/_tmp.pdf', f'out/Novorichni_podarunky_Office_Better_{SLUG}.pdf'
pdf = pikepdf.open(src)
for obj in list(pdf.objects):
    if isinstance(obj, pikepdf.Stream) and obj.get('/Subtype') == '/Image' and obj.get('/Filter') == '/FlateDecode':
        if obj.get('/ColorSpace') is None or str(obj.get('/ColorSpace')) == '/DeviceGray': continue
        try: pil = pikepdf.PdfImage(obj).as_pil_image().convert('RGB')
        except Exception: continue
        buf = io.BytesIO(); pil.save(buf, 'JPEG', quality=82)
        obj.write(buf.getvalue(), filter=pikepdf.Name.DCTDecode)
        obj.ColorSpace = pikepdf.Name.DeviceRGB; obj.BitsPerComponent = 8
        if '/DecodeParms' in obj: del obj['/DecodeParms']
# унікальні назви вбудованих шрифтів: деякі переглядачі плутають однакові назви і ламають відступи між літерами
import string, itertools
seen = set(); tags = (''.join(t) for t in itertools.product(string.ascii_uppercase, repeat=6))
for obj in list(pdf.objects):
    if isinstance(obj, pikepdf.Dictionary) and obj.get('/Type') == '/Font' and obj.get('/Subtype') == '/Type0':
        name = str(obj.BaseFont)[1:]
        if name in seen:
            base = name.split('+', 1)[-1]
            while True:
                t = next(tags)
                new = f'{t}+{base}'
                if new not in seen: break
            obj.BaseFont = pikepdf.Name('/' + new)
            for d in obj.DescendantFonts:
                d.BaseFont = pikepdf.Name('/' + new)
                if '/FontDescriptor' in d: d.FontDescriptor.FontName = pikepdf.Name('/' + new)
            name = new
        seen.add(name)
pdf.save(dst, compress_streams=True, object_stream_mode=pikepdf.ObjectStreamMode.generate)


os.remove('out/_tmp.pdf'); os.remove('out/_tmp.html')
print('Готово:', dst, os.path.getsize(dst)//1024, 'KB')
